Welcome to my janky prototype for SUPERMARKET MADNESS!

The object of the game is to pick up as many of the requested items as possible before time runs out.
Move with WASD and press E when you're on a green area to open the 'shelf' menu.
Use your mouse to select the correct item. Picking the wrong item will cause you to lose time.
Your timer will refresh once you pick up all the items in the current request.
You don't have to pick the items up in order.
The maximum time you have to pick up your items will decrease the longer you play but you can 
increase this time if you are on a streak without messing up.

Currently the walls don't do a good job of being walls so just move around them like you normally would
and try to not cheat.
The game needs a lot of point/timer balancing but my highscore after a few plays was 460.